"use strict";
module.exports = {
    aws_table_name: "humanManagement",
    aws_local_config: {},
    aws_remote_config: {
        accessKeyId: "AKIARAHLNRIHZ7XVJ7U6",
        secretAccessKey: "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",
        region: "eu-central-1",
    },
};
