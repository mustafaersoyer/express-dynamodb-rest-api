#!/bin/bash

export NODE_OPTIONS="${NODE_OPTIONS} --require /opt/otel-extension-internal-node"

exec "$@"
